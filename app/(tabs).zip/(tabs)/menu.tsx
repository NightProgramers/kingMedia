import Menu from "@/screens/menu";

export default function MenuPage() {
  return <Menu/>;
}